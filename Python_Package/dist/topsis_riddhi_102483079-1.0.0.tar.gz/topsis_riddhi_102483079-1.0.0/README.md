# Topsis

This repository contains the implementation of the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Python Package
Package Name: topsis-riddhi-102483079 

Install using:
```bash
pip install topsis-riddhi-102483079
